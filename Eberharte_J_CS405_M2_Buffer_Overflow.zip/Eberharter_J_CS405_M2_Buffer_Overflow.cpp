// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
// By: Joshua Eberharter

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;		// header

	const std::string account_number = "CharlieBrown42";		// initialize variables
	char user_input[20];										// additionally, you could use std::string class instead of c strings

	std::cout << "Enter a value: ";								// prompt user for input
	std::cin.getline(user_input, 20);							// get user input with a maximum 20 charcters, including null character (prevents buffer overflow)

	std::cout << "You entered: " << user_input << " at memory address: " << &user_input << std::endl;				// display user input with memory address
	std::cout << "Account Number = " << account_number << " at memory address: " << &account_number << std::endl;	// display account number with memory address
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
